import React from 'react';
export default class HelloReact extends React.Component {
    render() {
        return (
            <div>
            hello from react
            </div>
        )
    }
}